/********************************************************************************************************
*
*    ģ������ : ���λ�����
*    �ļ����� : Leo_CIRCLEBUFFER
*    ��    �� : V1.0
*    ˵    �� : ��ʵ��Ϊ��SDCard�洢 2k ��������ԸĽ�ʹ���κδ�С�Ĵ�ȡ
*
*    �޸ļ�¼ :
*        �汾��    ����          ����     
*        V1.0    2019-04-04     WangCb   
*
*    Copyright (C), 2018-2020, Department of Precision Instrument Engineering ,Tsinghua University  
*
********************************************************************************************************/


#include "Leo_CIRCLEBUFFER.h"



//���λ����� ��ʼ��
uint8_t ucCircleBuffer_INIT(leo_circlebuffer * mSDCard_CircleBuffer)
{
    memset(mSDCard_CircleBuffer->tBuffer,0,sizeof(mSDCard_CircleBuffer->tBuffer));
    mSDCard_CircleBuffer->tCounter = 0;
    mSDCard_CircleBuffer->pSave = mSDCard_CircleBuffer->tBuffer;
    mSDCard_CircleBuffer->pLoad = mSDCard_CircleBuffer->tBuffer;
    return 0;
}


//���λ����� �洢����    
uint8_t ucCircleBuffer_SaveData(leo_circlebuffer * mSDCard_CircleBuffer,uint8_t const* pBuffer,uint16_t mSize)
{
    if((mSDCard_CircleBuffer->pSave + mSize) <= (mSDCard_CircleBuffer->tBuffer + configSDCard_BufferSize))
    {
        memcpy(mSDCard_CircleBuffer->pSave,pBuffer,mSize);
        mSDCard_CircleBuffer->pSave += mSize;
        mSDCard_CircleBuffer->tCounter += mSize;
        if(mSDCard_CircleBuffer->pSave == (mSDCard_CircleBuffer->tBuffer + configSDCard_BufferSize))
        {
            mSDCard_CircleBuffer->pSave = mSDCard_CircleBuffer->tBuffer;
        }
    }else
    {
        uint16_t tFirstSize,tSecondSize;
        tFirstSize = mSDCard_CircleBuffer->tBuffer + configSDCard_BufferSize - mSDCard_CircleBuffer->pSave;
        tSecondSize = mSize-tFirstSize;
        memcpy(mSDCard_CircleBuffer->pSave,pBuffer,tFirstSize);
        mSDCard_CircleBuffer->pSave = mSDCard_CircleBuffer->tBuffer;
        memcpy(mSDCard_CircleBuffer->pSave,(pBuffer+tFirstSize),tSecondSize);
        mSDCard_CircleBuffer->pSave += tSecondSize;
        mSDCard_CircleBuffer->tCounter += mSize;
    }
    return 0;
}


//���λ����� ��ȡ����
uint8_t ucCircleBuffer_LoadData(leo_circlebuffer * mSDCard_CircleBuffer)
{
    if(mSDCard_CircleBuffer->tCounter < configSDCard_SaveSize)
        return 1;
    
    mSDCard_CircleBuffer->tCounter -= configSDCard_SaveSize;
    mSDCard_CircleBuffer->pLoad += configSDCard_SaveSize;
    if(mSDCard_CircleBuffer->pLoad == (mSDCard_CircleBuffer->tBuffer + configSDCard_BufferSize))
        mSDCard_CircleBuffer->pLoad = mSDCard_CircleBuffer->tBuffer;
    return 0;    
}


